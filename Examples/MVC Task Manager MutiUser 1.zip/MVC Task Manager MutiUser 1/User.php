<?php

class User {
	public $firstName = '';
	public $lastName = '';
	public $id = '';
}

?>
