<?php
	session_start();

	print "<p>GET data:<br />\n";
	print_r($_GET);
	print "</p>\n";

	print "<p>POST data:<br />\n";
	print_r($_POST);
	print "</p>\n";
	
	print "<p>SESSION data:<br />\n";
	print_r($_SESSION);
	print "</p>\n";
	
	if ($count = $_SESSION['count']) {
		$count++;
		$_SESSION['count'] = $count;
		print "<p>Visits = $count</p>\n";
	} else {
		$_SESSION['count'] = 1;
		print "<p>This is a first access!</p>\n";
	}
?>