<?php
$servername = "server_name_goes_here";
$username = "user_name_goes_here";
$password = "password_goes_here";
$dbname = "database_name_goes_here";
?>