<?php
$servername = "put_server_name_here";
$username = "put_user_name_here";
$password = "put_password_here";
$dbname = "put_database_name_here";
?>