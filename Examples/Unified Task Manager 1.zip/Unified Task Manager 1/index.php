<?php
	require('web_utils.php');
	
	$message = '';
	
	$target = $_GET['target'];
	$action = $_POST['action'];
	
	switch($action) {
		case 'delete':
			$message = deleteTask();
			break;
		case 'add':
			$message = addTask();
			break;
	}
	
	switch($target) {
		case 'new':
			presentTaskForm();
			break;
		default:
			presentTaskList($message);
	}
	
	

	// functions are defined below
	// eventually these will be moved to individual php files
	
	function presentTaskList($message = "") {
	
		$stylesheet = 'taskmanager.css';
	
		$tasks = array();

		// Create connection
		require('db_credentials.php');
		$mysqli = new mysqli($servername, $username, $password, $dbname);
	
		if ($mysqli->connect_error) {
			$message = $mysqli->connect_error;
		} else {
			$sql = "SELECT * FROM tasks";
			if ($result = $mysqli->query($sql)) {
				if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
						array_push($tasks, $row);
					}
				}
				$result->close();
			} else {
				$message = $mysqli->error;
			}
			$mysqli->close();
		}
	
		print generatePageHTML("Tasks", generateTaskTableHTML($tasks, $message), $stylesheet);
	}
	
	function generateTaskTableHTML($tasks, $message) {
		$html = "<h1>Tasks</h1>\n";
		
		if ($message) {
			$html .= "<p class='message'>$message</p>\n";
		}
		
		$html .= "<p><a class='taskButton' href='index.php?target=new'>+ Add Task</a></p>\n";
	
		if (count($tasks) < 1) {
			$html .= "<p>No tasks to display!</p>\n";
			return $html;
		}
	
		$html .= "<table>\n";
		$html .= "<tr><th>actions</th><th>add date</th><th>completed date</th><th>title</th><th>description</th><th>category</th></tr>\n";
	
		foreach ($tasks as $task) {
			$id = $task['id'];
			$addDate = $task['addDate'];
			$completedDate = ($task['completedDate']) ? $task['completedDate'] : '';
			$title = $task['title'];
			$description = ($task['description']) ? $task['description'] : '';
			$category = $task['category'];
			
			$html .= "<tr><td><form action='index.php' method='post'><input type='hidden' name='action' value='delete' /><input type='hidden' name='id' value='$id' /><input type='submit' value='Delete'></form></td><td>$addDate</td><td>$completedDate</td><td>$title</td><td>$description</td><td>$category</td></tr>\n";
		}
		$html .= "</table>\n";
	
		return $html;
	}
	
	function deleteTask() {
		$id = $_POST['id'];
	
		$message = "";
	
		if (!$id) {
			$message = "No task was specified to delete.";
		} else {
			// Create connection
			require('db_credentials.php');
			$mysqli = new mysqli($servername, $username, $password, $dbname);
			// Check connection
			if ($mysqli->connect_error) {
				$message = $mysqli->connect_error;
			} else {
				$id = $mysqli->real_escape_string($id);
				$sql = "DELETE FROM tasks WHERE id = $id";
				if ( $result = $mysqli->query($sql) ) {
					$message = "Task was deleted.";
				} else {
					$message = $mysqli->error;
				}
				$mysqli->close();
			}
		}
	
		return $message;
	}
	
	function presentTaskForm() {
		$html = <<<EOT
<!DOCTYPE html>
<html>
<head>
<title>Task Manager</title>
<link rel="stylesheet" type="text/css" href="taskmanager.css">
</head>
<body>
<h1>Tasks</h1>
<form action="index.php" method="post">
  <input type="hidden" name="action" value="add" />
  <p>Category<br />
  <select name="category">
	  <option value="personal">personal</option>
	  <option value="school">school</option>
	  <option value="work">work</option>
	  <option value="uncategorized" selected>uncategorized</option>
  </select>
  </p>

  <p>Title<br />
  <input type="text" name="title" value="" placeholder="title" maxlength="255" size="80"></p>

  <p>Description<br />
  <textarea name="description" rows="6" cols="80" placeholder="description"></textarea></p>
  <input type="submit" value="Submit">
</form>
</body>
</html>
EOT;

		print $html;
	}
	
	function addTask() {
		$message = '';
	
		$category = $_POST['category'];
		$title = $_POST['title'] ? $_POST['title'] : "untitled";
		$description = $_POST['description'] ? $_POST['description'] : "";

		// Create connection
		require('db_credentials.php');
		$mysqli = new mysqli($servername, $username, $password, $dbname);

		// Check connection
		if ($mysqli->connect_error) {
			$message = $mysqli->connect_error;
		} else {
			$category = $mysqli->real_escape_string($category);
			$title = $mysqli->real_escape_string($title);
			$description = $mysqli->real_escape_string($description);
	
			$sql = "INSERT INTO tasks (title, description, category, addDate) VALUES ('$title', '$description', '$category', NOW())";
	
			if ($result = $mysqli->query($sql)) {
				$message = "Task was added";
			} else {
				$message = $mysqli->error;
			}

		}
		
		return $message;
	}
	
?>