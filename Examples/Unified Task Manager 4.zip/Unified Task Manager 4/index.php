<?php
	require('web_utils.php');
	
	session_start();
	
	$message = '';
	
	$target = $_GET['target'];
	$action = $_POST['action'];
	
	switch($action) {
		case 'delete':
			$message = deleteTask();
			break;
		case 'add':
			$message = addTask();
			break;
		case 'set_completed':
			$message = setCompletionStatus('completed');
			break;
		case 'set_not_completed':
			$message = setCompletionStatus('not completed');
			break;
	}
	
	switch($target) {
		case 'new':
			presentTaskForm();
			break;
		default:
			presentTaskList($message);
	}
	
	

	// functions are defined below
	// eventually these will be moved to individual php files
	
	function presentTaskList($message = "") {
		$stylesheet = 'taskmanager.css';
		
		$orderBy = $_SESSION['orderby'] ? $_SESSION['orderby'] : 'title';
		$orderDirection = $_SESSION['orderdirection'] ? $_SESSION['orderdirection'] : 'asc';
		
		if ($_GET['orderby']) {
			if ($orderBy == $_GET['orderby']) {
				if ($orderDirection == 'asc') {
					$orderDirection = 'desc';
				} else {
					$orderDirection = 'asc';
				}
			} else {
				$orderDirection = 'asc';
			}
			$orderBy = $_GET['orderby'];
		}
		
		$_SESSION['orderby'] = $orderBy;
		$_SESSION['orderdirection'] = $orderDirection;
	
		$tasks = array();

		// Create connection
		require('db_credentials.php');
		$mysqli = new mysqli($servername, $username, $password, $dbname);
	
		if ($mysqli->connect_error) {
			$message = $mysqli->connect_error;
		} else {
			$orderBy = $mysqli->real_escape_string($orderBy);
			$orderDirection = $mysqli->real_escape_string($orderDirection);
			$sql = "SELECT * FROM tasks ORDER BY $orderBy $orderDirection";
			if ($result = $mysqli->query($sql)) {
				if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
						array_push($tasks, $row);
					}
				}
				$result->close();
			} else {
				$message = $mysqli->error;
			}
			$mysqli->close();
		}
	
		print generatePageHTML("Tasks", generateTaskTableHTML($tasks, $message, $orderBy, $orderDirection), $stylesheet);
	}
	
	function generateTaskTableHTML($tasks, $message, $orderBy, $orderDirection) {
		$html = "<h1>Tasks</h1>\n";
		
		if ($message) {
			$html .= "<p class='message'>$message</p>\n";
		}
		
		$html .= "<p><a class='taskButton' href='index.php?target=new'>+ Add Task</a></p>\n";
	
		if (count($tasks) < 1) {
			$html .= "<p>No tasks to display!</p>\n";
			return $html;
		}
	
		$html .= "<table>\n";
		$html .= "<tr><th>actions</th><th>completed</th>";
		
		$columns = array(array('name' => 'addDate', 'label' => 'add date'), 
						 array('name' => 'completedDate', 'label' => 'completed date'), 
						 array('name' => 'title', 'label' => 'title'), 
						 array('name' => 'description', 'label' => 'description'), 
						 array('name' => 'category', 'label' => 'category'));
		
		// geometric shapes in unicode
		// http://jrgraphix.net/r/Unicode/25A0-25FF
		foreach ($columns as $column) {
			$name = $column['name'];
			$label = $column['label'];
			if ($name == $orderBy) {
				if ($orderDirection == 'asc') {
					$label .= " &#x25BC;";  // ▼
				} else {
					$label .= " &#x25B2;";  // ▲
				}
			}
			$html .= "<th><a class='order' href='index.php?orderby=$name'>$label</a></th>";
		}
	
		foreach ($tasks as $task) {
			$id = $task['id'];
			$addDate = $task['addDate'];
			$completedDate = ($task['completedDate']) ? $task['completedDate'] : '';
			$title = $task['title'];
			$description = ($task['description']) ? $task['description'] : '';
			$category = $task['category'];
			
			$completedAction = 'set_completed';
			$completedLabel = 'not completed';
			if ($completedDate) {
				$completedAction = 'set_not_completed';
				$completedLabel = 'completed';
			}
			
			$html .= "<tr><td><form action='index.php' method='post'><input type='hidden' name='action' value='delete' /><input type='hidden' name='id' value='$id' /><input type='submit' value='Delete'></form></td><td><form action='index.php' method='post'><input type='hidden' name='action' value='$completedAction' /><input type='hidden' name='id' value='$id' /><input type='submit' value='$completedLabel'></form></td><td>$addDate</td><td>$completedDate</td><td>$title</td><td>$description</td><td>$category</td></tr>\n";
		}
		$html .= "</table>\n";
	
		return $html;
	}
	
	function deleteTask() {
		$id = $_POST['id'];
	
		$message = "";
	
		if (!$id) {
			$message = "No task was specified to delete.";
		} else {
			// Create connection
			require('db_credentials.php');
			$mysqli = new mysqli($servername, $username, $password, $dbname);
			// Check connection
			if ($mysqli->connect_error) {
				$message = $mysqli->connect_error;
			} else {
				$id = $mysqli->real_escape_string($id);
				$sql = "DELETE FROM tasks WHERE id = $id";
				if ( $result = $mysqli->query($sql) ) {
					$message = "Task was deleted.";
				} else {
					$message = $mysqli->error;
				}
				$mysqli->close();
			}
		}
	
		return $message;
	}
	
	function setCompletionStatus($status) {
		$id = $_POST['id'];
	
		$message = "";
		
		$completedDate = 'null';
		if ($status == 'completed') {
			$completedDate = 'NOW()';
		}
	
		if (!$id) {
			$message = "No task was specified to change completion status.";
		} else {
			// Create connection
			require('db_credentials.php');
			$mysqli = new mysqli($servername, $username, $password, $dbname);
			// Check connection
			if ($mysqli->connect_error) {
				$message = $mysqli->connect_error;
			} else {
				$id = $mysqli->real_escape_string($id);
				$sql = "UPDATE tasks SET completedDate = $completedDate WHERE id = '$id'";
				if ( $result = $mysqli->query($sql) ) {
					$message = "Task was updated to $status.";
				} else {
					$message = $mysqli->error;
				}
				$mysqli->close();
			}
		}
	
		return $message;
	}
	
	function presentTaskForm() {
		$html = <<<EOT
<!DOCTYPE html>
<html>
<head>
<title>Task Manager</title>
<link rel="stylesheet" type="text/css" href="taskmanager.css">
</head>
<body>
<h1>Tasks</h1>
<form action="index.php" method="post">
  <input type="hidden" name="action" value="add" />
  <p>Category<br />
  <select name="category">
	  <option value="personal">personal</option>
	  <option value="school">school</option>
	  <option value="work">work</option>
	  <option value="uncategorized" selected>uncategorized</option>
  </select>
  </p>

  <p>Title<br />
  <input type="text" name="title" value="" placeholder="title" maxlength="255" size="80"></p>

  <p>Description<br />
  <textarea name="description" rows="6" cols="80" placeholder="description"></textarea></p>
  <input type="submit" value="Submit">
</form>
</body>
</html>
EOT;

		print $html;
	}
	
	function addTask() {
		$message = '';
	
		$category = $_POST['category'];
		$title = $_POST['title'] ? $_POST['title'] : "untitled";
		$description = $_POST['description'] ? $_POST['description'] : "";

		// Create connection
		require('db_credentials.php');
		$mysqli = new mysqli($servername, $username, $password, $dbname);

		// Check connection
		if ($mysqli->connect_error) {
			$message = $mysqli->connect_error;
		} else {
			$category = $mysqli->real_escape_string($category);
			$title = $mysqli->real_escape_string($title);
			$description = $mysqli->real_escape_string($description);
	
			$sql = "INSERT INTO tasks (title, description, category, addDate) VALUES ('$title', '$description', '$category', NOW())";
	
			if ($result = $mysqli->query($sql)) {
				$message = "Task was added";
			} else {
				$message = $mysqli->error;
			}

		}
		
		return $message;
	}
	
?>